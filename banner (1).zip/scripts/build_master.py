#!/usr/bin/env python3
"""
build_master.py — poora project ek file mein (MASTER.md)

Kya karta hai:
  - Folder scan karta hai
  - Har .py / .json / .sh / .md / .txt file dhoondhta hai
  - Duplicate detect karta hai (content hash se)
  - Har Python file ka logic nikalta hai (docstring + functions)
  - AI on hai toh 2-3 line summary bhi likhta hai
  - Sab kuch docs/MASTER.md mein likh deta hai

AI kya karta:
  - Har file padhta hai
  - Plain English/Hinglish mein 2-3 line likhta hai "ye file kya karti hai"
  - Ek line padh ke samajh aa jaata hai
  - AI off hai toh sirf code embed hota (summary nahi)

Usage:
  python3 scripts/build_master.py           # auto-detect AI
  python3 scripts/build_master.py --ai      # AI on
  python3 scripts/build_master.py --no-ai   # AI off
"""
import os, re, json, ast, sys, hashlib, urllib.request
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DOCS = ROOT / "docs"
OUT = DOCS / "MASTER.md"
LOGIC_FILE = ROOT / "LOGIC.md"
AI_CACHE = DOCS / ".ai_cache.json"

SKIP_DIRS = {".git", "__pycache__", ".venv", "venv", "node_modules",
             "_pre_cleanup", "backups", ".pytest_cache", ".mypy_cache",
             "_backups", ".idea", ".vscode",
             "sessions", "logs", "exports", "failed_accounts",
             "state", "db", "temp", "tmp", "cache", ".cache"}

CODE_EXT = {".py": "python", ".js": "javascript", ".ts": "typescript",
            ".sh": "bash", ".rb": "ruby", ".go": "go", ".rs": "rust",
            ".java": "java", ".c": "c", ".cpp": "cpp", ".h": "c",
            ".php": "php", ".swift": "swift", ".kt": "kotlin"}
DATA_EXT = {".json": "json", ".yaml": "yaml", ".yml": "yaml",
            ".toml": "toml", ".ini": "ini", ".cfg": "ini", ".xml": "xml"}
DOC_EXT = {".md": "markdown", ".txt": "text", ".html": "html",
           ".css": "css", ".sql": "sql"}
ALL_EXT = {}
ALL_EXT.update(CODE_EXT)
ALL_EXT.update(DATA_EXT)
ALL_EXT.update(DOC_EXT)
EXTRA_NAMES = {"Dockerfile", "Makefile", "Procfile", "requirements.txt",
               ".env", ".env.example", ".gitignore"}
JSON_SUMMARY_THRESHOLD = 10000

# ╔════════════════════════════════════════════════════╗
# ║  AI TOGGLE — True = AI on,  False = AI off        ║
# ╚════════════════════════════════════════════════════╝
AI_ENABLED = False       # <- YAHAN BADLO (True / False)



# ═══════════════════════════════════════════════════════
#  HINGLISH PRINTS
# ═══════════════════════════════════════════════════════
def hprint(tag, msg):
    print(f"[{tag}] {msg}", flush=True)


def skip_file(name):
    if name.startswith(".") and name not in {".env", ".env.example", ".gitignore"}:
        return True
    if name.endswith((".pyc", ".pyo", ".so", ".tar.gz", ".zip", ".log",
                      ".db", ".sqlite", ".sqlite3")):
        return True
    if ".bak_" in name or ".bakfix" in name or name.endswith(".bak"):
        return True
    return False


def has_dup_suffix(name):
    return bool(re.search(r"\s*\(\d+\)", name))


def valid_identifier(name):
    base = os.path.splitext(name)[0]
    return base.isidentifier()


def read(p):
    try:
        return open(p, encoding="utf-8", errors="replace").read()
    except Exception:
        return None


def read_bytes(p):
    try:
        return open(p, "rb").read()
    except Exception:
        return b""


# ═══════════════════════════════════════════════════════
#  DISCOVERY + SMART DEDUP
# ═══════════════════════════════════════════════════════
def discover():
    groups = {}
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".")]
        for f in sorted(filenames):
            if skip_file(f):
                continue
            if f in ("build_master.py", "docs_sync.py", "make_send.py"):
                continue
            full = os.path.join(dirpath, f)
            rel = os.path.relpath(full, ROOT)
            if rel.startswith("docs/") or rel.startswith("docs" + os.sep):
                continue
            ext = os.path.splitext(f)[1].lower()
            if not (ext in ALL_EXT or f in EXTRA_NAMES or not ext):
                continue
            data = read_bytes(full)
            if not data:
                continue
            h = hashlib.sha256(data).hexdigest()
            try:
                mt = os.path.getmtime(full)
            except Exception:
                mt = 0
            groups.setdefault(h, []).append((rel, full, mt, len(data)))

    # import index — kaunsi files project mein import hoti hain
    import_index = set()
    for h, grp in groups.items():
        for rel, full, _, _ in grp:
            if not rel.endswith(".py"):
                continue
            content = read(full) or ""
            for m in re.finditer(r"^\s*(?:from|import)\s+([A-Za-z0-9_\.]+)",
                                 content, re.MULTILINE):
                import_index.add(m.group(1))
                import_index.add(m.group(1).split(".")[-1])

    files = []
    dupes = []

    for h, grp in groups.items():
        if len(grp) == 1:
            rel, full, _, _ = grp[0]
            files.append((rel, full))
            continue

        scored = []
        for rel, full, mt, size in grp:
            name = os.path.basename(rel)
            base = os.path.splitext(name)[0]
            score = 0
            reasons = []

            if not has_dup_suffix(name):
                score += 30
                reasons.append("clean name")
            else:
                score -= 20

            if name.endswith(".py"):
                if valid_identifier(name):
                    score += 15
                    reasons.append("valid identifier")
                else:
                    score -= 10
                if base in import_index:
                    score += 40
                    reasons.append("imported")
                parent = os.path.basename(os.path.dirname(rel))
                if parent and f"{parent}.{base}" in import_index:
                    score += 30
                    reasons.append(f"imported as {parent}.{base}")

            parts = rel.split(os.sep)
            for bad in ("old", "backup", "backups", "temp", "tmp", "test"):
                if bad in [p.lower() for p in parts[:-1]]:
                    score -= 15
                    reasons.append(f"in '{bad}' folder")

            score += mt * 1e-10
            score -= len(parts) * 0.5
            scored.append((score, rel, full, mt, reasons))

        scored.sort(key=lambda x: -x[0])
        winner = scored[0]
        files.append((winner[1], winner[2]))
        for score, rel, full, mt, reasons in scored[1:]:
            why = ", ".join(winner[4][:2]) if winner[4] else "analysis"
            dupes.append((rel, winner[1], why))

    files.sort(key=lambda x: x[0])
    dupes.sort(key=lambda x: x[0])
    return files, dupes


# ═══════════════════════════════════════════════════════
#  LOGIC EXTRACT (Python)
# ═══════════════════════════════════════════════════════
def extract_py_logic(code):
    try:
        t = ast.parse(code)
    except SyntaxError:
        return None
    info = {"docstring": (ast.get_docstring(t) or "").strip(),
            "functions": [], "classes": []}
    for n in t.body:
        if isinstance(n, ast.FunctionDef):
            args = [a.arg for a in n.args.args]
            doc = (ast.get_docstring(n) or "").strip().split("\n")[0][:100]
            info["functions"].append({"name": n.name, "args": args, "doc": doc})
        elif isinstance(n, ast.ClassDef):
            methods = [m.name for m in n.body if isinstance(m, ast.FunctionDef)]
            doc = (ast.get_docstring(n) or "").strip().split("\n")[0][:100]
            info["classes"].append({"name": n.name, "methods": methods, "doc": doc})
    return info


def format_py_logic(info):
    if not info:
        return []
    out = []
    if info["docstring"]:
        out.append("**Docstring:** " + info["docstring"].replace("\n", " ")[:200])
        out.append("")
    if info["classes"]:
        out.append("**Classes:**")
        for c in info["classes"]:
            line = f"- `{c['name']}`"
            if c["methods"]:
                line += " — methods: " + ", ".join(c["methods"][:8])
            if c["doc"]:
                line += f"  · {c['doc']}"
            out.append(line)
        out.append("")
    if info["functions"]:
        out.append("**Functions:**")
        for f in info["functions"]:
            line = f"- `{f['name']}({', '.join(f['args'])})`"
            if f["doc"]:
                line += f"  · {f['doc']}"
            out.append(line)
        out.append("")
    return out


# ═══════════════════════════════════════════════════════
#  AI CALL
# ═══════════════════════════════════════════════════════
def _load_cache():
    try:
        return json.loads(AI_CACHE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_cache(c):
    try:
        DOCS.mkdir(parents=True, exist_ok=True)
        AI_CACHE.write_text(json.dumps(c, indent=2, ensure_ascii=False),
                            encoding="utf-8")
    except Exception:
        pass


def _file_hash(code):
    return hashlib.sha256(code.encode("utf-8", "replace")).hexdigest()[:16]


def _call_ai(prompt, provider, key):
    """AI se summary maango. SDK pehle, fallback requests."""
    try:
        from openai import OpenAI

        if provider == "air":
            base = os.environ.get("AIR_BASE_URL", "https://api.airouter.in/v1").rstrip("/")
            model = os.environ.get("AIR_MODEL", "deepseek/deepseek-v4.1-flash")
            client = OpenAI(api_key=key, base_url=base)
        elif provider == "deepseek":
            model = os.environ.get("DEEPSEEK_MODEL", "deepseek-chat")
            client = OpenAI(api_key=key, base_url="https://api.deepseek.com/v1")
        elif provider == "openai":
            model = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
            client = OpenAI(api_key=key)
        elif provider == "gemini":
            url = ("https://generativelanguage.googleapis.com/v1beta/"
                   f"models/gemini-1.5-flash:generateContent?key={key}")
            body = json.dumps({
                "contents": [{"parts": [{"text": prompt}]}],
                "generationConfig": {"maxOutputTokens": 200, "temperature": 0.3},
            }).encode()
            req = urllib.request.Request(
                url, data=body, method="POST",
                headers={"Content-Type": "application/json",
                         "User-Agent": "Mozilla/5.0 (docsbot)"})
            with urllib.request.urlopen(req, timeout=30) as r:
                data = json.loads(r.read().decode())
            return data["candidates"][0]["content"]["parts"][0]["text"].strip()
        else:
            return None

        resp = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=200,
            temperature=0.3,
        )
        return resp.choices[0].message.content.strip()

    except ImportError:
        try:
            import requests
            if provider == "air":
                base = os.environ.get("AIR_BASE_URL",
                                      "https://api.airouter.in/v1").rstrip("/")
                model = os.environ.get("AIR_MODEL", "deepseek/deepseek-v4.1-flash")
                url = base + "/chat/completions"
            elif provider == "deepseek":
                model = os.environ.get("DEEPSEEK_MODEL", "deepseek-chat")
                url = "https://api.deepseek.com/v1/chat/completions"
            elif provider == "openai":
                model = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
                url = "https://api.openai.com/v1/chat/completions"
            else:
                return None
            r = requests.post(
                url,
                json={"model": model,
                      "messages": [{"role": "user", "content": prompt}],
                      "max_tokens": 200, "temperature": 0.3},
                headers={"Authorization": f"Bearer {key}",
                         "Content-Type": "application/json",
                         "User-Agent": "Mozilla/5.0 (Linux; Android 12)"},
                timeout=30,
            )
            if r.status_code != 200:
                sys.stderr.write(f"[ai] HTTP {r.status_code}: {r.text[:200]}\n")
                return None
            return r.json()["choices"][0]["message"]["content"].strip()
        except Exception as e:
            sys.stderr.write(f"[ai] fallback error: {e}\n")
            return None
    except Exception as e:
        sys.stderr.write(f"[ai] {provider} error: {e}\n")
        return None


def ai_summary_file(rel, code, provider, key, cache, counters):
    h = _file_hash(code)
    cached = cache.get(rel, {})
    if cached.get("hash") == h and cached.get("summary"):
        counters["cached"] += 1
        return cached["summary"], True

    snippet = code[:6000]
    prompt = (f"File: {rel}\n\n```\n{snippet}\n```\n\n"
              f"In 2-3 concise lines (English), explain what this file does "
              f"and how it fits. No preamble, plain text only.")
    summary = _call_ai(prompt, provider, key)
    if summary:
        cache[rel] = {"hash": h, "summary": summary}
        counters["new"] += 1
        return summary, False
    counters["failed"] += 1
    return None, False


def _pick_provider():
    if os.environ.get("AIR_API_KEY"):
        return "air", os.environ["AIR_API_KEY"]
    for p, k in [("deepseek", "DEEPSEEK_API_KEY"),
                 ("gemini", "GEMINI_API_KEY"),
                 ("openai", "OPENAI_API_KEY")]:
        if os.environ.get(k):
            return p, os.environ[k]
    return None, None


# ═══════════════════════════════════════════════════════
#  JSON smart
# ═══════════════════════════════════════════════════════
def json_smart(rel, content):
    size = len(content.encode("utf-8"))
    if size <= JSON_SUMMARY_THRESHOLD:
        return ["### FILE: " + rel, "", "```json", content.rstrip(), "```", ""]
    try:
        data = json.loads(content)
    except Exception:
        return ["### FILE: " + rel + f"  *(unparseable, {size} bytes)*", ""]
    o = [f"### FILE: {rel}  _(summarized)_", "", f"> **Size:** {size:,} bytes", ""]
    if isinstance(data, list):
        o.append("- **Type:** array")
        o.append(f"- **Count:** {len(data)}")
        if data and isinstance(data[0], dict):
            o.append("- **Keys:** " + ", ".join(f"`{k}`" for k in list(data[0].keys())))
        o.append("")
        o.append("```json")
        o.append(json.dumps(data[:3], indent=2, ensure_ascii=False))
        o.append("```")
    elif isinstance(data, dict):
        o.append("- **Type:** object")
        o.append(f"- **Top keys:** {len(data)}")
        o.append("- **Keys:** " + ", ".join(f"`{k}`" for k in list(data.keys())[:20]))
        for k, v in data.items():
            if isinstance(v, list) and len(v) > 20:
                o.append("")
                o.append(f"- **`{k}` array:** {len(v)}")
                o.append("")
                o.append("```json")
                o.append(json.dumps(v[:3], indent=2, ensure_ascii=False))
                o.append("```")
                break
    o.append("")
    return o


# ═══════════════════════════════════════════════════════
#  TREE
# ═══════════════════════════════════════════════════════
def tree(root, prefix="", depth=0, max_d=6):
    if depth > max_d:
        return []
    try:
        entries = sorted(os.listdir(root))
    except Exception:
        return []
    dirs = [e for e in entries if os.path.isdir(os.path.join(root, e))
            and e not in SKIP_DIRS and not e.startswith(".")]
    files = [f for f in entries if os.path.isfile(os.path.join(root, f))
             and not skip_file(f)]
    items = [(d, True) for d in dirs] + [(f, False) for f in files]
    out = []
    for i, (n, is_d) in enumerate(items):
        last = i == len(items) - 1
        out.append(prefix + ("└── " if last else "├── ") + n + ("/" if is_d else ""))
        if is_d:
            out.extend(tree(os.path.join(root, n),
                            prefix + ("    " if last else "│   "),
                            depth + 1, max_d))
    return out


# ═══════════════════════════════════════════════════════
#  MAIN
# ═══════════════════════════════════════════════════════
def main():
    # AI mode — top constant se decide (AI_ENABLED)
    ai_provider, ai_key = (None, None)
    use_ai = False

    if AI_ENABLED:
        ai_provider, ai_key = _pick_provider()
        if ai_provider:
            print(f"[ai] AI ON — provider: {ai_provider}")
            use_ai = True
        else:
            print("[ai] AI ON chaha par koi API key nahi mili — OFF chala rahe hain")
    else:
        print("[ai] AI OFF (AI_ENABLED = False)")

    os.makedirs(DOCS, exist_ok=True)
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cache = _load_cache() if use_ai else {}
    counters = {"new": 0, "cached": 0, "failed": 0}

    print()
    hprint("scan", "files dhoondh raha hoon...")
    files, dupes = discover()
    hprint("scan", f"{len(files)} files mili, {len(dupes)} duplicate skip kiye")

    py_files = [(r, p) for r, p in files
                if os.path.splitext(r)[1].lower() in CODE_EXT]
    json_files = [(r, p) for r, p in files
                  if os.path.splitext(r)[1].lower() in DATA_EXT]
    sh_files = [(r, p) for r, p in files
                if os.path.splitext(r)[1].lower() == ".sh"]
    doc_files = [(r, p) for r, p in files
                 if os.path.splitext(r)[1].lower() in DOC_EXT and r != "LOGIC.md"]
    known = set(r for r, _ in py_files + json_files + sh_files + doc_files)
    extra = [(r, p) for r, p in files if r not in known and r != "LOGIC.md"]

    if use_ai:
        hprint("ai", f"{len(py_files)} Python files pe AI summary likh raha hoon...")

    b = []
    b.append("# PROJECT — MASTER FILE")
    b.append("")
    b.append(f"**Compiled:** {now}")
    b.append(f"**Root:** `{ROOT}/`")
    b.append(f"**Files embedded:** {len(files)}")
    b.append(f"**Duplicates skipped:** {len(dupes)}")
    b.append(f"**AI summaries:** {'ON — ' + ai_provider if use_ai else 'OFF'}")
    b.append("")
    b.append("Search: `Ctrl+F` for `### FILE:` to jump to any file.")
    b.append("Regenerate: `python3 scripts/build_master.py [--ai|--no-ai]`")
    b.append("")
    b.append("---")
    b.append("")

    if LOGIC_FILE.exists():
        logic = read(str(LOGIC_FILE))
        if logic:
            b.append("## PROJECT LOGIC (manual)")
            b.append("")
            b.append(logic.rstrip())
            b.append("")
            b.append("---")
            b.append("")

    b.append("## TREE")
    b.append("")
    b.append("```")
    b.append(ROOT.name + "/")
    b.extend(tree(str(ROOT)))
    b.append("```")
    b.append("")
    b.append("---")
    b.append("")

    if dupes:
        b.append("## DUPLICATES SKIPPED (analysis-based)")
        b.append("")
        b.append(f"> {len(dupes)} identical-content files skipped. "
                 "Winner: clean name > valid identifier > imported-by-project > mtime.")
        b.append("")
        b.append("| Duplicate (skipped) | Embedded instead | Why |")
        b.append("|---------------------|------------------|-----|")
        for dup_rel, win_rel, why in dupes:
            b.append(f"| `{dup_rel}` | `{win_rel}` | {why} |")
        b.append("")
        b.append("---")
        b.append("")

    if py_files:
        b.append("## CODE FILES")
        b.append("")
        for i, (rel, path) in enumerate(py_files, 1):
            content = read(path)
            if content is None:
                continue
            lang = CODE_EXT.get(os.path.splitext(rel)[1].lower(), "text")
            b.append(f"### FILE: {rel}")
            b.append("")

            if use_ai:
                summary, cached = ai_summary_file(rel, content, ai_provider,
                                                  ai_key, cache, counters)
                if summary:
                    tag = " (cached)" if cached else ""
                    b.append(f"**AI summary{tag}:** {summary}")
                    b.append("")

            if lang == "python":
                info = extract_py_logic(content)
                if info:
                    lines = format_py_logic(info)
                    if lines:
                        b.extend(lines)

            b.append(f"```{lang}")
            b.append(content.rstrip())
            b.append("```")
            b.append("")

            if use_ai and i % 5 == 0:
                hprint("ai", f"  {i}/{len(py_files)} files ho gayi")

    if use_ai:
        _save_cache(cache)
        hprint("ai", f"naye: {counters['new']}, cache se: {counters['cached']}, fail: {counters['failed']}")

    if json_files:
        b.append("---")
        b.append("")
        b.append("## DATA FILES")
        b.append("")
        for rel, path in json_files:
            content = read(path)
            if content is None:
                continue
            if rel.endswith(".json"):
                b.extend(json_smart(rel, content))
            else:
                lang = DATA_EXT.get(os.path.splitext(rel)[1].lower(), "text")
                b.append(f"### FILE: {rel}")
                b.append("")
                b.append(f"```{lang}")
                b.append(content.rstrip())
                b.append("```")
                b.append("")

    if sh_files:
        b.append("---")
        b.append("")
        b.append("## SHELL SCRIPTS")
        b.append("")
        for rel, path in sh_files:
            content = read(path)
            if content is None:
                continue
            b.append(f"### FILE: {rel}")
            b.append("")
            b.append("```bash")
            b.append(content.rstrip())
            b.append("```")
            b.append("")

    if doc_files:
        b.append("---")
        b.append("")
        b.append("## DOCS")
        b.append("")
        for rel, path in doc_files:
            content = read(path)
            if content is None:
                continue
            lang = DOC_EXT.get(os.path.splitext(rel)[1].lower(), "text")
            b.append(f"### FILE: {rel}")
            b.append("")
            b.append(f"```{lang}")
            b.append(content.rstrip())
            b.append("```")
            b.append("")

    if extra:
        b.append("---")
        b.append("")
        b.append("## OTHER FILES")
        b.append("")
        for rel, path in extra:
            content = read(path)
            if content is None:
                continue
            b.append(f"### FILE: {rel}")
            b.append("")
            b.append("```text")
            b.append(content.rstrip())
            b.append("```")
            b.append("")

    b.append("---")
    b.append("")
    b.append("END OF MASTER FILE")
    b.append("")

    body = "\n".join(b)
    OUT.write_text(body, encoding="utf-8")

    print()
    hprint("build", str(OUT))
    hprint("size",  f"{len(body):,} bytes")
    hprint("files", f"{len(files)} embedded")
    hprint("dupes", f"{len(dupes)} skip (analysis-based)")
    hprint("ai",    "ON — " + ai_provider if use_ai else "OFF")
    hprint("when",  now)


if __name__ == "__main__":
    main()