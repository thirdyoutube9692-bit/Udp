#!/usr/bin/env python3
"""
make_send.py — MASTER.md padh ke SEND.md auto-generate karta hai.

Kya karta hai:
  - MASTER.md se tree, file counts, top functions nikalta
  - Project ka type detect karta (jwt/account/bot/etc)
  - Har section ke saath ek template SEND.md banata
  - AI ko dene ke liye ready

Usage:
    python3 scripts/make_send.py
    (MASTER.md ke saath same folder mein SEND.md banayega)
"""
import os, re, json
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DOCS = ROOT / "docs"
MASTER = DOCS / "MASTER.md"
OUT = DOCS / "SEND.md"


def read(p):
    try:
        return open(p, encoding="utf-8", errors="replace").read()
    except Exception:
        return ""


# ── 1. MASTER.md se info nikalo ──
def parse_master(md):
    info = {
        "root": "",
        "files_embedded": 0,
        "dupes": 0,
        "python_count": 0,
        "json_count": 0,
        "sh_count": 0,
        "py_files": [],
        "top_functions": [],   # (file, fn_name, args)
        "top_classes": [],     # (file, cls_name)
        "docstrings": [],      # (file, first line)
        "imports": set(),
        "keywords": set(),
    }

    # header
    m = re.search(r"\*\*Root:\*\*\s*`([^`]+)`", md)
    if m: info["root"] = m.group(1)
    m = re.search(r"\*\*Files embedded:\*\*\s*(\d+)", md)
    if m: info["files_embedded"] = int(m.group(1))
    m = re.search(r"\*\*Duplicates skipped:\*\*\s*(\d+)", md)
    if m: info["dupes"] = int(m.group(1))

    # file list from ### FILE:
    for fm in re.finditer(r"^### FILE:\s*(.+?)$", md, re.MULTILINE):
        name = fm.group(1).strip()
        info["py_files"].append(name)
        if name.endswith(".py"):
            info["python_count"] += 1
        elif name.endswith(".json"):
            info["json_count"] += 1
        elif name.endswith(".sh"):
            info["sh_count"] += 1

    # extract each python file's functions/classes/docstring
    # pattern: ### FILE: x.py\n\n(maybe **Docstring:** ...)\n**Functions:**\n- `fn(args)` ...
    blocks = re.split(r"^### FILE:", md, flags=re.MULTILINE)
    for blk in blocks[1:]:
        first_line = blk.split("\n", 1)[0].strip()
        fname = first_line
        if not fname.endswith(".py"):
            continue

        # docstring
        dm = re.search(r"\*\*Docstring:\*\*\s*(.+)", blk)
        if dm:
            ds = dm.group(1).strip()[:120]
            if ds:
                info["docstrings"].append((fname, ds))

        # classes
        cm = re.search(r"\*\*Classes:\*\*\n((?:- .+\n?)+)", blk)
        if cm:
            for cl in re.finditer(r"- `(\w+)`", cm.group(1)):
                info["top_classes"].append((fname, cl.group(1)))

        # functions
        fm2 = re.search(r"\*\*Functions:\*\*\n((?:- .+\n?)+)", blk)
        if fm2:
            for fn in re.finditer(r"- `(\w+)\(([^)]*)\)`", fm2.group(1)):
                info["top_functions"].append((fname, fn.group(1), fn.group(2)))

    # keyword detection — imports + common names
    kws = ["telegram", "flask", "fastapi", "aiohttp", "requests",
           "protobuf", "jwt", "oauth", "garena", "majorlogin",
           "majorglogin", "socketserver", "tcp", "websocket",
           "sqlalchemy", "sqlite", "redis", "celery",
           "pytest", "docker", "uvicorn", "gunicorn",
           "like", "spam", "emoji", "clan", "guild", "frnd"]
    low = md.lower()
    for k in kws:
        if k in low:
            info["keywords"].add(k)

    return info


# ── 2. Project type detect ──
def detect_project_type(info):
    kw = info["keywords"]
    types = []
    if "telegram" in kw:
        types.append("Telegram bot")
    if "flask" in kw or "fastapi" in kw:
        types.append("REST API")
    if "garena" in kw or "majorlogin" in kw:
        types.append("Garena/Free Fire automation")
    if "jwt" in kw or "oauth" in kw:
        types.append("JWT/OAuth auth")
    if "protobuf" in kw:
        types.append("protobuf RPC")
    if "socketserver" in kw or "tcp" in kw:
        types.append("TCP bot/client")
    if "like" in kw:
        types.append("like service")
    if "spam" in kw:
        types.append("spam tool")
    if not types:
        types.append("Python project")
    return types


# ── 3. Tree se structure nikalo ──
def extract_top_dirs(md):
    m = re.search(r"## TREE\n\n```\n(.+?)\n```", md, re.DOTALL)
    if not m:
        return []
    tree = m.group(1)
    dirs = set()
    for line in tree.split("\n"):
        # lines like "├── folder/"
        dm = re.match(r"^[│├└─\s]+([\w\-_]+)/", line)
        if dm:
            dirs.add(dm.group(1))
    return sorted(dirs)[:15]


# ── 4. Function name ke hisaab se feature summary ──
def summarise_features(info):
    feats = set()
    for f, fn, args in info["top_functions"]:
        low = fn.lower()
        if any(x in low for x in ("login", "auth", "token")):
            feats.add("authentication / token generation")
        if any(x in low for x in ("register", "signup", "create")):
            feats.add("account creation")
        if any(x in low for x in ("like", "follow")):
            feats.add("like service")
        if any(x in low for x in ("send", "message", "chat", "spam")):
            feats.add("message/chat handlers")
        if any(x in low for x in ("join", "leave", "room", "clan", "guild")):
            feats.add("room/clan actions")
        if any(x in low for x in ("emote", "emoji", "sticker")):
            feats.add("emote/emoji features")
        if any(x in low for x in ("decrypt", "encrypt", "decode", "encode")):
            feats.add("encryption / packet codec")
        if any(x in low for x in ("tcp", "socket", "connect")):
            feats.add("TCP connection handling")
        if any(x in low for x in ("bot", "command", "handler")):
            feats.add("command handlers")
    return sorted(feats)


# ── 5. SEND.md banao ──
def build_send(info, project_type, top_dirs, features):
    now = datetime.now().strftime("%Y-%m-%d %H:%M")

    # top files (by size proxy — we don't have sizes here, use function count)
    fn_counts = {}
    for f, _, _ in info["top_functions"]:
        fn_counts[f] = fn_counts.get(f, 0) + 1
    big_files = sorted(fn_counts.items(), key=lambda x: -x[1])[:8]

    # build the project description
    ptype_str = ", ".join(project_type)
    dirs_str = ", ".join(f"`{d}/`" for d in top_dirs) if top_dirs else "(flat structure)"
    feats_str = "\n".join(f"- {f}" for f in features) if features else "- (analyze from code)"

    big_files_str = "\n".join(f"- `{f}` — {c} functions" for f, c in big_files)
    if not big_files_str:
        big_files_str = "(analyze from MASTER.md)"

    send = f"""# Project Send Template — AI ko dene ke liye

Auto-generated: {now}
Source: `{MASTER}`

---

## COPY-PASTE START (yahan se neeche sab copy karo)

---

Bhai, ye mera project hai. `MASTER.md` mein poora code hai — ek file mein sab kuch.

## Project kya hai

Ye ek **{ptype_str}** project hai.

**Project size:**
- {info['files_embedded']} files (embedded in MASTER.md)
- {info['dupes']} duplicates skipped
- {info['python_count']} Python files
- {info['json_count']} JSON files
- {info['sh_count']} shell scripts

**Top-level directories:**
{dirs_str}

**Ye project ye kaam karta hai:**
{feats_str}

**Sabse important files (function count ke hisaab se):**
{big_files_str}

## MASTER.md ke andar kya hai

- **TREE** — poora folder structure
- **CODE FILES** — har `.py` file ka poora source code
- **DATA FILES** — JSON files ka content
- **SHELL SCRIPTS** — `.sh` files
- **DUPLICATES SKIPPED** — kaunsi files same thi, kaunsi rakhi
- **Docstrings + Functions** — har file ka logic summary

Search karne ke liye: `Ctrl+F` → `### FILE:` → koi bhi file ka code mil jaayega.

## Mujhe kya chahiye

Is project ko **top-level** banana hai. Matlab:

1. **Architecture** — abhi sab ek folder mein mixed hai. Modular packages mein todo.
2. **Code quality** — duplicate code hataao, bade functions todho, type hints lagao, PEP8 follow karo.
3. **Security** — hardcoded secrets (tokens, AES keys) ko `.env` mein daalo. SSL verify on karo. Input validation.
4. **Features** — kya add karna chahiye, kya hatana chahiye.
5. **Testing** — unit tests, CI/CD.
6. **Documentation** — README, setup guide.

## Kaise jawab dena

- **Specific bolo** — file ka naam, function ka naam, line number
- **Generic advice mat do** — "code modular karo" jaisa kuch nahi
- **Concrete code do** — refactored file ka poora code likho
- **Priority order** — kya pehle, kya baad mein
- **Sab kuch batao** — chhota-bada, kuch skip mat karo

## Extra info

- Language: Python 3
- Root: `{info['root']}`
- MASTER.md size: ~{os.path.getsize(MASTER) // 1024 if MASTER.exists() else 0} KB

Bas itna. Ab `MASTER.md` padho aur batao kya kya improve karun.

---

## COPY-PASTE END
"""
    return send


# ── 6. Main ──
def main():
    if not MASTER.exists():
        print(f"[!] MASTER.md nahi mila: {MASTER}")
        print("    pehle docs_sync.py chalao")
        return

    print(f"[read] {MASTER}")
    md = read(str(MASTER))
    print(f"[info] size: {len(md):,} chars")

    print("[parse] analyzing structure...")
    info = parse_master(md)
    print(f"  files: {info['files_embedded']}")
    print(f"  python: {info['python_count']}")
    print(f"  duplicates: {info['dupes']}")
    print(f"  functions found: {len(info['top_functions'])}")
    print(f"  classes found: {len(info['top_classes'])}")

    print("[detect] project type...")
    ptype = detect_project_type(info)
    print(f"  types: {', '.join(ptype)}")

    print("[extract] top dirs...")
    dirs = extract_top_dirs(md)
    print(f"  dirs: {', '.join(dirs)}")

    print("[summarise] features...")
    feats = summarise_features(info)
    print(f"  features: {len(feats)}")

    print("[write] SEND.md...")
    send = build_send(info, ptype, dirs, feats)
    OUT.write_text(send, encoding="utf-8")

    print()
    print(f"[done] {OUT}")
    print(f"[size] {len(send):,} bytes")
    print()
    print("Ab AI ko ye do:")
    print(f"  1. {OUT}")
    print(f"  2. {MASTER}")
    print("  Dono ek saath bhejo.")


if __name__ == "__main__":
    main()
