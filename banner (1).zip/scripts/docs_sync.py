#!/usr/bin/env python3
"""
docs_sync.py — rebuild all docs. Auto-discovers all files.
Calls build_master.py (with --ai if API key present).
Generates: MASTER.md, STRUCTURE.md, FILES.md, CHANGES.log

Usage:
    python3 scripts/docs_sync.py
    python3 scripts/docs_sync.py --ai
"""
import os, subprocess, sys
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DOCS = ROOT / "docs"
DOCS.mkdir(parents=True, exist_ok=True)

SKIP = {".git", "__pycache__", ".venv", "venv", "node_modules",
        "_pre_cleanup", "backups", ".pytest_cache", ".mypy_cache",
        "_backups", ".idea", ".vscode",
        "sessions", "logs", "exports", "failed_accounts",
        "state", "db", "temp", "tmp", "cache", ".cache"}


def skip_file(name):
    if name.startswith(".") and name not in {".env", ".env.example", ".gitignore"}:
        return True
    if name.endswith((".pyc", ".pyo", ".so", ".tar.gz", ".zip", ".log",
                      ".db", ".sqlite", ".sqlite3")):
        return True
    if ".bak_" in name or ".bakfix" in name or name.endswith(".bak"):
        return True
    return False


def tree(root, prefix="", depth=0, max_d=6):
    if depth > max_d:
        return []
    try:
        entries = sorted(os.listdir(root))
    except Exception:
        return []
    dirs = [e for e in entries if os.path.isdir(os.path.join(root, e))
            and e not in SKIP and not e.startswith(".")]
    files = [f for f in entries if os.path.isfile(os.path.join(root, f))
             and not skip_file(f)]
    items = [(d, True) for d in dirs] + [(f, False) for f in files]
    out = []
    for i, (n, is_d) in enumerate(items):
        last = i == len(items) - 1
        out.append(prefix + ("└── " if last else "├── ") + n + ("/" if is_d else ""))
        if is_d:
            out.extend(tree(os.path.join(root, n),
                            prefix + ("    " if last else "│   "),
                            depth + 1, max_d))
    return out


def walk_stats():
    total = 0
    by_ext = {}
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames[:] = [d for d in dirnames if d not in SKIP and not d.startswith(".")]
        for f in filenames:
            if skip_file(f):
                continue
            if f in ("build_master.py", "docs_sync.py"):
                continue
            rel = os.path.relpath(os.path.join(dirpath, f), ROOT)
            if rel.startswith("docs/") or rel.startswith("docs" + os.sep):
                continue
            ext = os.path.splitext(f)[1].lower() or "(no-ext)"
            by_ext[ext] = by_ext.get(ext, 0) + 1
            total += 1
    return total, by_ext


def has_ai_key():
    return any(os.environ.get(k) for k in
               ("AIR_API_KEY", "DEEPSEEK_API_KEY",
                "GEMINI_API_KEY", "OPENAI_API_KEY"))


now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# ── 1. MASTER.md — call build_master.py ──
# AI on/off is controlled by AI_ENABLED constant inside build_master.py
cmd = [sys.executable, str(HERE / "build_master.py")]

try:
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    print("[master]", "ok" if r.returncode == 0 else "FAIL")
    if r.stdout:
        for ln in r.stdout.strip().split("\n"):
            print("        ", ln)
    if r.returncode != 0 and r.stderr:
        print("         ", r.stderr.strip().split("\n")[-1])
except Exception as e:
    print("[master] skip:", e)

# ── 2. STRUCTURE.md ──
total, by_ext = walk_stats()
L = [
    "# PROJECT — STRUCTURE",
    "",
    f"**Updated:** {now}",
    f"**Root:** `{ROOT}/`",
    f"**Total files:** {total}",
    "",
    "---",
    "",
    "## TREE",
    "",
    "```",
    ROOT.name + "/",
]
L.extend(tree(str(ROOT)))
L.append("```")
L.append("")
L.append("---")
L.append("")
L.append("## FILE COUNT BY TYPE")
L.append("")
for ext in sorted(by_ext.keys()):
    L.append(f"- `{ext}` : {by_ext[ext]}")
L.append("")
L.append("---")
L.append("")
(DOCS / "STRUCTURE.md").write_text("\n".join(L), encoding="utf-8")
print("[structure] ok")

# ── 3. FILES.md ──
L = [
    "# PROJECT — FILE LIST",
    "",
    f"**Updated:** {now}",
    f"**Root:** `{ROOT}/`",
    "",
    "| File | Size |",
    "|------|------|",
]
for dirpath, dirnames, filenames in os.walk(ROOT):
    dirnames[:] = [d for d in dirnames if d not in SKIP and not d.startswith(".")]
    for f in sorted(filenames):
        if skip_file(f):
            continue
        if f in ("build_master.py", "docs_sync.py"):
            continue
        rel = os.path.relpath(os.path.join(dirpath, f), ROOT)
        if rel.startswith("docs/") or rel.startswith("docs" + os.sep):
            continue
        size = os.path.getsize(os.path.join(dirpath, f))
        L.append(f"| `{rel}` | {size:,} B |")
(DOCS / "FILES.md").write_text("\n".join(L), encoding="utf-8")
print("[files] ok")

# ── 4. CHANGES.log ──
with open(DOCS / "CHANGES.log", "a", encoding="utf-8") as f:
    f.write(f"[{now}] docs_sync\n")
print("[changes] ok")

# ── 5. SEND.md — call make_send.py ──
send_script = HERE / "make_send.py"
if send_script.exists():
    print("[send] SEND.md bana raha hoon...")
    try:
        r = subprocess.run([sys.executable, str(send_script)],
                           capture_output=True, text=True, timeout=120)
        print("[send]", "OK" if r.returncode == 0 else "FAIL")
        if r.stdout:
            for ln in r.stdout.strip().split("\n"):
                print("        ", ln)
    except Exception as e:
        print("[send] skip:", e)
else:
    print("[send] make_send.py nahi mila — skip")

print()
print("DONE.")
print("Root: " + str(ROOT))
print("Updated: " + now)